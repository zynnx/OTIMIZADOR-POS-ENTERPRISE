﻿#=========================================================
# Utils.psm1
# Utility functions
#=========================================================

function Convert-Bytes {

    param(
        [Int64]$Bytes
    )
    if ($Bytes -ge 1TB) {
        return "{0:N2} TB" -f ($Bytes / 1TB)
    }
    elseif ($Bytes -ge 1GB) {
        return "{0:N2} GB" -f ($Bytes / 1GB)
    }
    elseif ($Bytes -ge 1MB) {
        return "{0:N2} MB" -f ($Bytes / 1MB)
    }
    elseif ($Bytes -ge 1KB) {
        return "{0:N2} KB" -f ($Bytes / 1KB)
    }
    else {
        return "$Bytes Bytes"
    }

}

#---------------------------------------------------------

function Show-Header {

    param(
        [string]$Title
    )

    Clear-Host

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host (" {0}" -f $Title) -ForegroundColor White
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

#---------------------------------------------------------

function Pause-App {

    if ($Global:App.AutomaticMode) {

        return

    }

    Write-Host ""

    Read-Host "Press ENTER to continue"

}

#---------------------------------------------------------

function Write-Success {
    param([string]$Message)
    Write-Host "[ OK ] $Message" -ForegroundColor Green
}

#---------------------------------------------------------

function Write-WarningMessage {
    param([string]$Message)
    Write-Host "[ WARNING ] $Message" -ForegroundColor Yellow
}

#---------------------------------------------------------

function Write-ErrorMessage {
    param([string]$Message)
    Write-Host "[ ERROR ] $Message" -ForegroundColor Red
}

#---------------------------------------------------------

function Start-Stopwatch {
    return [System.Diagnostics.Stopwatch]::StartNew()
}

#---------------------------------------------------------

function Stop-Stopwatch {
    param(
        $Watch
    )
    $Watch.Stop()
    return $Watch.Elapsed
}

#---------------------------------------------------------

function Format-Time {
    param(
        [TimeSpan]$Elapsed
    )
    return "{0:00}:{1:00}:{2:00}" -f `
        $Elapsed.Hours,
    $Elapsed.Minutes,
    $Elapsed.Seconds
}

#---------------------------------------------------------

function Show-ProgressSimple {

    param(
        [string]$Activity,
        [int]$Current,
        [int]$Total
    )
    if ($Total -eq 0) {
        return
    }

    $Percent = [math]::Round(($Current / $Total) * 100)

    Write-Progress `
        -Activity $Activity `
        -Status "$Percent %" `
        -PercentComplete $Percent
}

#---------------------------------------------------------

function Draw-Line {
    param(
        [char]$Character = "=",
        [int]$Length = 60
    )
    Write-Host ($Character.ToString() * $Length) -ForegroundColor DarkCyan
}

#---------------------------------------------------------

function Get-ModuleItems {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SubFolder,

        [Parameter(Mandatory = $true)]
        [string]$FunctionPattern,

        [string]$BasePath = "$Global:AppRoot\Modules"
    )

    $Items = @()
    $ModulesPath = Join-Path $BasePath $SubFolder

    if (-not (Test-Path $ModulesPath)) {
        Write-Warning "Pasta de módulos não encontrada: $ModulesPath"
        return $Items
    }

    # Nomes dos módulos (sem extensão) presentes nessa subpasta
    $ModuleNamesInFolder = @(
        Get-ChildItem -Path $ModulesPath -Filter "*.psm1" -File |
        Select-Object -ExpandProperty BaseName
    )

    if ($ModuleNamesInFolder.Count -eq 0) {
        Write-Warning "No .psm1 modules found in: $ModulesPath"
        return $Items
    }

    $MatchedFunctions = @(
        Get-Command -CommandType Function -Name $FunctionPattern -Module $ModuleNamesInFolder -ErrorAction SilentlyContinue
    )

    foreach ($func in $MatchedFunctions) {

        try {

            $Result = & $func.Name

            if ($null -ne $Result) {
                $Items += @($Result)
            }

        }
        catch {

            Write-Warning "Failed to collect '$($func.Name)': $($_.Exception.Message)"

        }

    }

    return @($Items)
}

#---------------------------------------------------------

function New-ModuleResult {

    param(
        [Parameter(Mandatory)]
        [string]$Module,
        [int]$Success = 0,
        [int]$Errors = 0,
        [object[]]$Details = @(),
        [object]$Elapsed = $null
    )

    return [PSCustomObject]@{
        Module   = $Module
        Date     = Get-Date
        Success  = $Success
        Errors   = $Errors
        Duration = if ($Elapsed) {
            Format-Time $Elapsed
        }
        else {
            "00:00:00"
        }
        Details  = $Details
    }
}

Export-ModuleMember -Function *
